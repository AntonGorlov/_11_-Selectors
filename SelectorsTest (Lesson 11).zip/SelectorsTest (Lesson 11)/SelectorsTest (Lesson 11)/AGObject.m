//
//  AGObject.m
//  SelectorsTest (Lesson 11)
//
//  Created by Anton Gorlov on 27.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGObject.h"

@implementation AGObject
-(void) testMethod {
    NSLog(@"Object testMethod");
}
//если приватный метод
-(NSString*) secret {
return @"I have a secret";
}
@end
