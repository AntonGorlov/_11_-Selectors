//
//  AppDelegate.m
//  SelectorsTest (Lesson 11)
//
//  Created by Anton Gorlov on 27.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGObject.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
   // [self testMethod];
    //создадим тип данных селектор
    SEL selector1=@selector(testMethod);
    //вызываем селектор.
    [self performSelector:selector1];
    
    //соз метод с  параметром (Обязательно в названии метода ":")
    SEL selector2=@selector(testMethod2:);
    [self performSelector:selector2 withObject:@"test string"];
    
    //соз метод с 2 мя параметрами (Обязательно в названиях методов ":")
    SEL selector3=@selector(testMethod: parameter2:);
    [self performSelector:selector3 withObject:@"string" withObject:@"string2"];
    
    //для закрепления материала
    SEL selector4=@selector(nameSurname:nameSurname2:);
    [self performSelector:selector4 withObject:@"Anton" withObject:@"Gorlov"];
    
    //задержка появления метода через определенное время
    [self performSelector:selector1 withObject:nil afterDelay:3.f];
    
    
    AGObject*obj=[[AGObject alloc]init];
    [obj performSelector:selector1];
    
    //приватный метод
    NSString*secret =[obj performSelector:@selector(secret)];
    NSLog(@"secret %@",secret);
    
    //соз строки из селекторов
    NSString*a=NSStringFromSelector(selector1);
    SEL sel=NSSelectorFromString(a);
    
    //соз метод с 3-мя параметрами
    NSString*string=[self testMethodParameter1:3 paremeter2:5.6f paremeter3:1.5f];
    NSLog(@"string =%@",string);
    
    return YES;
}
//методы
-(void) testMethod {
    NSLog(@"TestMethod");
}
-(void) testMethod2:(NSString*) string {
    NSLog(@"testMethod2 = %@",string);
}
-(void) testMethod:(NSString*) string parameter2:(NSString*) string2 {
    NSLog(@"testMethod:%@ ,parameter2:%@",string,string2);
}
-(void) nameSurname:(NSString*) name nameSurname2:(NSString*) nickname{
    NSLog(@"name:%@, surname:%@",name,nickname);
}
 //соз метод с 3-мя параметрами

-(NSString*) testMethodParameter1:(NSInteger) intValue paremeter2:(CGFloat) floatValue paremeter3:(double) doubleValue {
    return [NSString stringWithFormat:@"testMethofParameter1:%ld,paremeter2:%f, paremeter3:%f",(long)intValue,floatValue,doubleValue];
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
